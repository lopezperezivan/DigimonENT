package digi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * Clase principal que inicia el juego de Digimon.
 * Permite al jugador iniciar batallas y seleccionar opciones.
 * 
 * @author Autor
 */
public class Principal {
   
	/**
     * Método principal que inicia la ejecución del programa.
     * 
     * @param args Argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random rand = new Random();

        try {
            System.out.println("Introduce el nombre del Domador:");
            String nombreDomador = scanner.nextLine();
            Domador domador = new Domador(nombreDomador);
            System.out.println("Bienvenido, " + domador.getNombre());

            List<Digimon> digimonsDisponibles = new ArrayList<>(Arrays.asList(
                new Digimon("Tailmon"),
                new Digimon("Piyomon"),
                new Digimon("Agumon"),
                new Digimon("Patamon"),
                new Digimon("Gabumon")
            ));

            // Seleccionar un Digimon aleatorio para el jugador
            Digimon digimonInicial = digimonsDisponibles.remove(rand.nextInt(digimonsDisponibles.size()));
            domador.addDigimon(digimonInicial);
            System.out.println("Has recibido a " + digimonInicial.getNombre() + " como tu primer Digimon.");

            boolean continuarJuego = true;
            while (continuarJuego) {
                System.out.println("Opciones: 1. Iniciar batalla, 2. Salir");
                int opcion = 0;
                try {
                    opcion = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Opción no válida. Por favor, introduce un número.");
                    scanner.nextLine(); // Limpiar el buffer del escáner
                    continue;
                }

                switch (opcion) {
                    case 1:
                        BatallaDigital batalla = new BatallaDigital(domador, digimonsDisponibles);
                        boolean jugadorGana = batalla.elige();
                        if (jugadorGana) {
                            System.out.println("¡Has ganado el juego! Gracias por jugar.");
                            continuarJuego = false;
                        } else if (domador.getDigimons().isEmpty()) { // Si no tiene digimons, significa que perdió
                            System.out.println("Has perdido el juego. Empieza de nuevo.");
                            continuarJuego = false;
                        }
                        break;
                    case 2:
                        System.out.println("Gracias por jugar.");
                        continuarJuego = false;
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        break;
                }
            }
        } catch (Exception e) {
            System.out.println("Se ha producido un error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
