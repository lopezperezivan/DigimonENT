package digi;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * Clase que representa una batalla digital entre Digimons.
 * Permite realizar ataques y determina el resultado de la batalla.
 * 
 * @author Autor
 */

public class BatallaDigital {
    private Domador domador;
    private List<Digimon> digimonsDisponibles;
    private Random rand = new Random();
    private Scanner scanner = new Scanner(System.in);

    /**
     * Constructor de la clase BatallaDigital.
     * 
     * @param domador El domador que participará en la batalla.
     * @param digimonsDisponibles La lista de Digimons disponibles para la batalla.
     */
    public BatallaDigital(Domador domador, List<Digimon> digimonsDisponibles) {
        this.domador = domador;
        this.digimonsDisponibles = digimonsDisponibles;
    }

    /**
     * Método que ejecuta la lógica de la batalla.
     * 
     * @return true si el jugador gana la batalla, false si pierde.
     */
    public boolean elige() {
        Digimon digimonJugador = seleccionarDigimonJugador();
        Digimon digimonRival = seleccionarDigimonRival();

        System.out.println("¡Comienza la batalla entre " + digimonJugador.getNombre() + " y " + digimonRival.getNombre() + "!");

        while (digimonJugador.getSalud() > 0 && digimonRival.getSalud() > 0) {
            System.out.println(digimonJugador);
            System.out.println(digimonRival);

            System.out.print("Elige el ataque para " + digimonJugador.getNombre() + " (1 o 2): ");
            int ataqueJugador = 0;
            try {
                ataqueJugador = scanner.nextInt();
            } catch (Exception e) {
                System.out.println("Opción no válida. Por favor, introduce un número.");
                scanner.nextLine(); // Limpiar el buffer del escáner
                continue;
            }

            if (ataqueJugador == 1) {
                digimonJugador.ataque1(digimonRival);
            } else if (ataqueJugador == 2) {
                digimonJugador.ataque2(digimonRival);
            } else {
                System.out.println("Opción no válida.");
                continue;
            }

            if (digimonRival.getSalud() <= 0) {
                System.out.println(digimonRival.getNombre() + " ha sido derrotado!");
                domador.addDigimon(digimonRival);
                digimonsDisponibles.remove(digimonRival);
                break;
            }

            int ataqueRival = rand.nextInt(2) + 1;
            if (ataqueRival == 1) {
                digimonRival.ataque1(digimonJugador);
            } else if (ataqueRival == 2) {
                digimonRival.ataque2(digimonJugador);
            }

            if (digimonJugador.getSalud() <= 0) {
                System.out.println(digimonJugador.getNombre() + " ha sido derrotado!");
                domador.getDigimons().remove(digimonJugador); // Eliminar Digimon derrotado del domador
                System.out.println("Has perdido el Digimon " + digimonJugador.getNombre());
                return false; // Retorna false si el jugador pierde
            }
        }

        if (domadorTieneDigimonsRequeridos()) {
            System.out.println("¡Felicidades! Has conseguido a Agumon, Patamon y Gabumon. ¡Has ganado el juego!");
            return true; // Retorna true si el jugador gana
        }

        return false; // Retorna false si la batalla termina sin ganar el juego
    }

    /**
     * Método para seleccionar el Digimon del jugador.
     * 
     * @return El Digimon seleccionado por el jugador.
     */
    private Digimon seleccionarDigimonJugador() {
        System.out.println("Elige tu Digimon:");
        List<Digimon> digimons = domador.getDigimons();
        for (int i = 0; i < digimons.size(); i++) {
            System.out.println((i + 1) + ". " + digimons.get(i).getNombre());
        }
        int eleccion = 0;
        try {
            eleccion = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("Opción no válida. Por favor, introduce un número.");
            scanner.nextLine(); // Limpiar el buffer del escáner
            return seleccionarDigimonJugador(); // Llamada recursiva para volver a intentar
        }
        return digimons.get(eleccion - 1);
    }

    /**
     * Método para seleccionar el Digimon rival.
     * 
     * @return El Digimon rival seleccionado.
     */
    private Digimon seleccionarDigimonRival() {
        int index = rand.nextInt(digimonsDisponibles.size());
        return digimonsDisponibles.get(index);
    }

    /**
     * Método para verificar si el domador tiene los Digimons requeridos para ganar.
     * 
     * @return true si el domador tiene a Agumon, Patamon y Gabumon, false de lo contrario.
     */
    private boolean domadorTieneDigimonsRequeridos() {
        boolean tieneAgumon = false;
        boolean tienePatamon = false;
        boolean tieneGabumon = false;

        for (Digimon digimon : domador.getDigimons()) {
            if (digimon.getNombre().equals("Agumon")) tieneAgumon = true;
            if (digimon.getNombre().equals("Patamon")) tienePatamon = true;
            if (digimon.getNombre().equals("Gabumon")) tieneGabumon = true;
        }

        return tieneAgumon && tienePatamon && tieneGabumon;
    }
}
