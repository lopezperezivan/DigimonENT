package digi;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa a un domador de Digimons.
 * 
 *@author Autor
 */
public class Domador {
    private String nombre;
    private List<Digimon> digimons;

    /**
     * Constructor de la clase Domador.
     * 
     * @param nombre Nombre del domador.
     */
    public Domador(String nombre) {
        this.nombre = nombre;
        this.digimons = new ArrayList<>();
    }

    /**
     * Obtener el nombre del domador.
     * 
     * @return Nombre del domador.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Añadir un Digimon al domador.
     * 
     * @param digimon Digimon a añadir.
     */
    public void addDigimon(Digimon digimon) {
        digimons.add(digimon);
    }

    /**
     * Obtener la lista de Digimons del domador.
     * 
     * @return Lista de Digimons.
     */
    public List<Digimon> getDigimons() {
        return digimons;
    }

    /**
     * Verificar si el domador tiene los Digimons requeridos para ganar.
     * 
     * @return true si el domador tiene a Agumon, Patamon y Gabumon, false de lo contrario.
     */
    public boolean tieneDigimonsRequeridos() {
        boolean tieneAgumon = false;
        boolean tienePatamon = false;
        boolean tieneGabumon = false;

        for (Digimon digimon : digimons) {
            if (digimon.getNombre().equals("Agumon")) tieneAgumon = true;
            if (digimon.getNombre().equals("Patamon")) tienePatamon = true;
            if (digimon.getNombre().equals("Gabumon")) tieneGabumon = true;
        }

        return tieneAgumon && tienePatamon && tieneGabumon;
    }
}
