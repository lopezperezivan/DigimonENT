package digi;
import java.util.Random;
import java.util.Scanner;


public class BatallaDigital {
    private Domador domador;
    private Digimon enemigo;
    private static final String[] DIGIMON_NAMES = {"Agumon", "Gabumon", "Patamon"};

    /**
     * Constructor de la clase BatallaDigital.
     * 
     * @param domador El domador que participará en la batalla.
     */
    public BatallaDigital(Domador domador) {
        this.domador = domador;
        Random rand = new Random();
        enemigo = new Digimon(DIGIMON_NAMES[rand.nextInt(DIGIMON_NAMES.length)]);
    }

    public void elige() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Elige un Digimon de tu equipo (0, 1 o 2): ");
        int choice = scanner.nextInt();
        if (choice >= 0 && choice < domador.getEquipo().size()) {
            Digimon elegido = domador.getEquipo().get(choice);
            pelea(elegido);
        } else {
            System.out.println("Elección no válida.");
        }
    }

    public void pelea(Digimon elegido) {
        Scanner scanner = new Scanner(System.in);
        while (enemigo.getSalud() > 0 && elegido.getSalud() > 0) {
            System.out.println("Elige una acción: 1. Ataque1, 2. Ataque2, 3. Capturar");
            int accion = scanner.nextInt();
            switch (accion) {
                case 1:
                    elegido.ataque1(enemigo);
                    break;
                case 2:
                    elegido.ataque2(enemigo);
                    break;
                case 3:
                    domador.capturar(enemigo);
                    return;
                default:
                    System.out.println("Acción no válida.");
            }
            if (enemigo.getSalud() > 0) {
                // Enemigo ataca de vuelta
                Random rand = new Random();
                int ataqueEnemigo = rand.nextInt(2) + 1;
                if (ataqueEnemigo == 1) {
                    enemigo.ataque1(elegido);
                } else {
                    enemigo.ataque2(elegido);
                }
            }
            System.out.println("Estado del enemigo: " + enemigo);
            System.out.println("Estado del Digimon elegido: " + elegido);
        }
        System.out.println("Batalla terminada.");
    }
}